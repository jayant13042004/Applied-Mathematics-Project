Applied Math Project --2023--

Time Series Analysis Folder

1. Contains Exponential Smoothing
2. Contains ARIMA + AR + MA model
3. Contains Regressive Model
4. Contains Deep Learning predictive models

--------------------------------------------

MADE BY:

1. SAHIL KUMAR
2. JAYANT JAGTAP
3. SHIRSENDU PAL