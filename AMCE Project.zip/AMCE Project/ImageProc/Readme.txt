Applied Math Project --2023--

Image Data Analysis Folder

1. Contains GMM predicitve model

--------------------------------------------

MADE BY:

1. SHIRSENDU PAL